
// Google Sheets Fixtures Integration Template
// Replace SHEET_ID and API_KEY with your own
async function loadFixtures() {
  const sheetId = "YOUR_SHEET_ID";
  const apiKey = "YOUR_API_KEY";
  const range = "Fixtures!A1:E50";
  const url = `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${range}?key=${apiKey}`;
  const response = await fetch(url);
  const data = await response.json();
  console.log(data);
}
loadFixtures();
